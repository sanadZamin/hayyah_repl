# Hayyah CRM – React Components

## Screens included
- **Login.tsx** — Split-panel login page
- **Dashboard.tsx** — Overview with KPI cards, revenue chart, top providers, recent orders
- **Customers.tsx** — Customer list with search, filters, and status badges
- **Orders.tsx** — Order management table with status tracking
- **Providers.tsx** — Provider directory with ratings and availability
- **_shared/AppLayout.tsx** — Collapsible sidebar nav used by all inner pages

## Dependencies
Install these in your React project:

```bash
npm install lucide-react
npm install -D tailwindcss
```

## Brand CSS variables
Add this to your global CSS file (e.g. `index.css`):

```css
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

:root {
  --hayyah-blue: #0088fb;
  --hayyah-mint: #53ffb0;
  --hayyah-navy: #0d2270;
}

body {
  font-family: 'Plus Jakarta Sans', sans-serif;
}
```

## Logo images
Place the files from `/public/images/` into your project's public folder.
Update image paths in the components if your project uses a different base path.

| File | Use |
|---|---|
| `hayyah-wordmark-blue.png` | Blue logo on light backgrounds |
| `hayyah-wordmark-white.png` | White logo on dark backgrounds (sidebar, login panel) |
| `hayyah-icon-blue.png` | Icon only – blue version |
| `hayyah-icon-white.png` | Icon only – white version (collapsed sidebar) |

## Usage example

```tsx
import AppLayout from './components/hayyah-crm/_shared/AppLayout';
import Dashboard from './components/hayyah-crm/Dashboard';

export default function App() {
  return (
    <AppLayout activePage="dashboard">
      <Dashboard />
    </AppLayout>
  );
}
```
