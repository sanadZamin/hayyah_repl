import React, { useState } from "react";
import { AppLayout } from "./_shared/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Search, 
  Calendar as CalendarIcon, 
  Eye, 
  Edit2, 
  XCircle,
  Download,
  Filter,
  MoreHorizontal,
  MapPin,
  User,
  Wrench,
  Clock,
  CheckCircle2,
  X
} from "lucide-react";

export function Orders() {
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const [selectedRows, setSelectedRows] = useState<string[]>([]);

  const stats = [
    { label: "Total", value: "1,284", color: "var(--hayyah-navy)" },
    { label: "Pending", value: "87", color: "amber-600" },
    { label: "In Progress", value: "43", color: "var(--hayyah-blue)" },
    { label: "Completed", value: "1,104", color: "emerald-600" },
    { label: "Cancelled", value: "50", color: "red-600" },
  ];

  const orders = [
    { id: "#HY-2024-081", customer: "Ahmed Al-Farsi", service: "Deep Cleaning", provider: "Omar K.", date: "Today, 10:30 AM", status: "Completed", amount: "SAR 450", payment: "Paid" },
    { id: "#HY-2024-082", customer: "Sarah Rahman", service: "Pest Control", provider: "Unassigned", date: "Today, 12:00 PM", status: "Pending", amount: "SAR 250", payment: "Pending" },
    { id: "#HY-2024-083", customer: "Mohammed N.", service: "AC Maintenance", provider: "Ali M.", date: "Today, 02:15 PM", status: "In Progress", amount: "SAR 300", payment: "Paid" },
    { id: "#HY-2024-084", customer: "Fatima Saeed", service: "Plumbing", provider: "Hassan T.", date: "Tomorrow, 09:00 AM", status: "Pending", amount: "SAR 150", payment: "Pending" },
    { id: "#HY-2024-085", customer: "Khalid Basheer", service: "Painting", provider: "Ibrahim W.", date: "Oct 24, 10:00 AM", status: "Completed", amount: "SAR 850", payment: "Paid" },
    { id: "#HY-2024-086", customer: "Aisha Al-Dosari", service: "Deep Cleaning", provider: "Omar K.", date: "Oct 24, 01:30 PM", status: "Cancelled", amount: "SAR 450", payment: "Refunded" },
    { id: "#HY-2024-087", customer: "Omar Tariq", service: "AC Maintenance", provider: "Ali M.", date: "Oct 23, 11:00 AM", status: "Completed", amount: "SAR 300", payment: "Paid" },
    { id: "#HY-2024-088", customer: "Leena Mansour", service: "Pest Control", provider: "Khaled S.", date: "Oct 23, 03:45 PM", status: "Completed", amount: "SAR 250", payment: "Paid" },
    { id: "#HY-2024-089", customer: "Youssef Ali", service: "Plumbing", provider: "Unassigned", date: "Oct 25, 08:30 AM", status: "Pending", amount: "SAR 150", payment: "Pending" },
    { id: "#HY-2024-090", customer: "Noura S.", service: "Deep Cleaning", provider: "Hassan T.", date: "Oct 22, 10:00 AM", status: "Completed", amount: "SAR 450", payment: "Paid" },
  ];

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "Completed": return "bg-[#53ffb0]/20 text-emerald-800";
      case "In Progress": return "bg-[#0088fb]/20 text-[#0088fb]";
      case "Pending": return "bg-amber-100 text-amber-800";
      case "Cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPaymentBadge = (status: string) => {
    switch(status) {
      case "Paid": return "bg-gray-100 text-gray-700";
      case "Pending": return "bg-orange-50 text-orange-600 border border-orange-200/50";
      case "Refunded": return "bg-gray-100 text-gray-500 italic";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const toggleRow = (id: string) => {
    setSelectedRows(prev => prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    if (selectedRows.length === orders.length) {
      setSelectedRows([]);
    } else {
      setSelectedRows(orders.map(o => o.id));
    }
  };

  const selectedData = orders.find(o => o.id === selectedOrder);

  return (
    <AppLayout activeNav="orders">
      <div className="flex h-full gap-6 relative">
        <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${selectedOrder ? 'lg:pr-[400px]' : ''}`}>
          
          {/* Header & Stats */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold" style={{ color: "var(--hayyah-navy)" }}>Orders</h1>
            <p className="text-gray-500 text-sm mt-1 mb-4">Manage and track all service orders</p>
            
            <div className="flex flex-wrap gap-3">
              {stats.map((stat, i) => (
                <Card key={i} className="rounded-xl border-none shadow-sm flex-1 min-w-[120px]">
                  <CardContent className="p-4 flex flex-col gap-1">
                    <span className="text-xs font-semibold text-gray-500 uppercase">{stat.label}</span>
                    <span className="text-xl font-bold" style={{ color: stat.color.startsWith('var') ? stat.color : undefined }} className={stat.color.startsWith('var') ? "" : `text-${stat.color}`}>{stat.value}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card className="rounded-2xl border-none shadow-sm bg-white flex flex-col flex-1 min-h-0 overflow-hidden relative">
            
            {/* Bulk Actions Bar (Overlay) */}
            {selectedRows.length > 0 && (
              <div className="absolute top-0 left-0 right-0 z-20 bg-[var(--hayyah-navy)] text-white p-3 flex items-center justify-between px-6">
                <span className="text-sm font-medium">{selectedRows.length} orders selected</span>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white border-none">
                    Assign Provider
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white border-none">
                    <Download className="w-4 h-4 mr-2" /> Export
                  </Button>
                  <Button size="sm" variant="destructive" className="bg-red-500/20 text-red-100 hover:bg-red-500/30 border-none">
                    Cancel Selected
                  </Button>
                </div>
              </div>
            )}

            {/* Filter Bar */}
            <div className="p-4 border-b border-gray-100 flex flex-wrap gap-3 items-center justify-between bg-white z-10">
              <div className="flex items-center gap-3 flex-wrap flex-1">
                <div className="relative w-full sm:w-64 max-w-sm">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input placeholder="Search orders..." className="pl-9 bg-gray-50 border-transparent h-9" />
                </div>
                
                <div className="flex items-center gap-2">
                  <Button variant="outline" className="h-9 gap-2 border-gray-200 text-gray-600 bg-white">
                    <CalendarIcon className="w-4 h-4" /> Date Range
                  </Button>
                  
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[140px] h-9 border-gray-200 bg-white">
                      <SelectValue placeholder="Service Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Services</SelectItem>
                      <SelectItem value="cleaning">Deep Cleaning</SelectItem>
                      <SelectItem value="pest">Pest Control</SelectItem>
                      <SelectItem value="ac">AC Maintenance</SelectItem>
                      <SelectItem value="plumbing">Plumbing</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select defaultValue="all">
                    <SelectTrigger className="w-[120px] h-9 border-gray-200 bg-white">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="flex-1 overflow-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10 shadow-[0_1px_0_0_#f3f4f6]">
                  <TableRow className="hover:bg-transparent border-none">
                    <TableHead className="w-12 px-4">
                      <Checkbox 
                        checked={selectedRows.length === orders.length && orders.length > 0}
                        onCheckedChange={toggleAll}
                      />
                    </TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3">Order ID</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3">Customer</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3">Service & Provider</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3">Schedule</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3">Amount</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3">Status</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-3 text-right pr-6">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => (
                    <TableRow 
                      key={order.id} 
                      className={`border-b border-gray-50 transition-colors ${selectedRows.includes(order.id) ? 'bg-[var(--hayyah-blue-light)]/30' : 'hover:bg-gray-50/50'}`}
                    >
                      <TableCell className="px-4">
                        <Checkbox 
                          checked={selectedRows.includes(order.id)}
                          onCheckedChange={() => toggleRow(order.id)}
                        />
                      </TableCell>
                      <TableCell className="font-medium" style={{ color: "var(--hayyah-navy)" }}>{order.id}</TableCell>
                      <TableCell className="font-medium text-gray-900">{order.customer}</TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-0.5">
                          <span className="font-medium text-sm text-gray-800">{order.service}</span>
                          <span className={`text-xs ${order.provider === 'Unassigned' ? 'text-amber-600 font-medium' : 'text-gray-500'}`}>
                            {order.provider}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-600 text-sm">{order.date}</TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1 items-start">
                          <span className="font-medium text-gray-900">{order.amount}</span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase tracking-wider font-semibold ${getPaymentBadge(order.payment)}`}>
                            {order.payment}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getStatusBadge(order.status)}`}>
                          {order.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-[var(--hayyah-blue)]" onClick={() => setSelectedOrder(order.id)}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-900">
                            <Edit2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </div>

        {/* Order Detail Drawer */}
        {selectedOrder && selectedData && (
          <div className="fixed inset-y-0 right-0 w-[400px] bg-white shadow-2xl border-l border-gray-100 z-50 transform transition-transform duration-300 flex flex-col lg:absolute lg:right-6 lg:top-0 lg:bottom-6 lg:rounded-2xl lg:h-auto lg:border lg:shadow-md">
            
            <div className="p-5 flex items-center justify-between border-b border-gray-100 bg-gray-50/50 rounded-t-2xl">
              <div>
                <h2 className="text-lg font-bold" style={{ color: "var(--hayyah-navy)" }}>Order {selectedData.id}</h2>
                <div className="mt-2 flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusBadge(selectedData.status)}`}>
                    {selectedData.status}
                  </span>
                  <span className="text-sm text-gray-500">• {selectedData.date}</span>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 bg-white rounded-full shadow-sm" onClick={() => setSelectedOrder(null)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              
              {/* Timeline */}
              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Order Status</h3>
                <div className="relative pl-3 space-y-6 before:absolute before:inset-y-2 before:left-[15px] before:w-[2px] before:bg-gray-100">
                  
                  <div className="relative flex gap-4">
                    <div className="absolute -left-3 top-1 w-[10px] h-[10px] rounded-full bg-emerald-500 ring-4 ring-white z-10" />
                    <div>
                      <p className="text-sm font-bold text-gray-900">Order Booked</p>
                      <p className="text-xs text-gray-500 mt-1">Oct 24, 08:00 AM</p>
                    </div>
                  </div>

                  <div className="relative flex gap-4">
                    <div className={`absolute -left-3 top-1 w-[10px] h-[10px] rounded-full ${selectedData.status === 'Pending' ? 'bg-gray-300' : 'bg-emerald-500'} ring-4 ring-white z-10`} />
                    <div>
                      <p className={`text-sm font-bold ${selectedData.status === 'Pending' ? 'text-gray-500' : 'text-gray-900'}`}>Provider Assigned</p>
                      {selectedData.provider !== 'Unassigned' && <p className="text-xs text-gray-500 mt-1">Oct 24, 08:30 AM • {selectedData.provider}</p>}
                    </div>
                  </div>

                  <div className="relative flex gap-4">
                    <div className={`absolute -left-3 top-1 w-[10px] h-[10px] rounded-full ${['Pending', 'Cancelled'].includes(selectedData.status) ? 'bg-gray-300' : (selectedData.status === 'In Progress' ? 'bg-[var(--hayyah-blue)]' : 'bg-emerald-500')} ring-4 ring-white z-10`} />
                    <div>
                      <p className={`text-sm font-bold ${['Pending', 'Cancelled'].includes(selectedData.status) ? 'text-gray-500' : 'text-gray-900'}`}>In Progress</p>
                      {selectedData.status === 'In Progress' && <p className="text-xs text-[var(--hayyah-blue)] font-medium mt-1">Provider is on site</p>}
                    </div>
                  </div>

                  <div className="relative flex gap-4">
                    <div className={`absolute -left-3 top-1 w-[10px] h-[10px] rounded-full ${selectedData.status === 'Completed' ? 'bg-emerald-500' : 'bg-gray-300'} ring-4 ring-white z-10`} />
                    <div>
                      <p className={`text-sm font-bold ${selectedData.status === 'Completed' ? 'text-gray-900' : 'text-gray-500'}`}>Completed</p>
                      {selectedData.status === 'Completed' && <p className="text-xs text-emerald-600 font-medium mt-1">Service finished successfully</p>}
                    </div>
                  </div>

                </div>
              </div>

              <div className="border-t border-gray-100 pt-6">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Service Details</h3>
                <div className="bg-gray-50 rounded-xl p-4 space-y-4">
                  <div className="flex items-start gap-3">
                    <Wrench className="w-4 h-4 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Service Type</p>
                      <p className="text-sm font-medium text-gray-900 mt-0.5">{selectedData.service}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Location</p>
                      <p className="text-sm font-medium text-gray-900 mt-0.5">Al Olaya District, Riyadh<br/>Building 45, Apt 12</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <User className="w-4 h-4 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Customer</p>
                      <p className="text-sm font-medium text-[var(--hayyah-blue)] mt-0.5 cursor-pointer hover:underline">{selectedData.customer}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Payment Summary</h3>
                  <span className={`text-[10px] px-2 py-0.5 rounded uppercase tracking-wider font-bold ${getPaymentBadge(selectedData.payment)}`}>
                    {selectedData.payment}
                  </span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-gray-600">
                    <span>Service Fee</span>
                    <span>{selectedData.amount}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>VAT (15%)</span>
                    <span>SAR {(parseInt(selectedData.amount.replace(/\D/g, '')) * 0.15).toFixed(2)}</span>
                  </div>
                  <div className="border-t border-dashed border-gray-200 mt-2 pt-2 flex justify-between font-bold text-gray-900 text-base">
                    <span>Total</span>
                    <span>SAR {(parseInt(selectedData.amount.replace(/\D/g, '')) * 1.15).toFixed(2)}</span>
                  </div>
                </div>
              </div>

            </div>

            <div className="p-4 border-t border-gray-100 bg-gray-50 rounded-b-2xl">
              {selectedData.status === 'Pending' ? (
                <Button className="w-full text-white shadow-sm" style={{ background: "var(--hayyah-blue)" }}>Assign Provider</Button>
              ) : selectedData.status === 'Completed' ? (
                <Button variant="outline" className="w-full bg-white border-gray-200">Download Invoice</Button>
              ) : (
                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1 bg-white border-gray-200 text-red-600 hover:text-red-700 hover:bg-red-50">Cancel Order</Button>
                  <Button className="flex-1 text-white shadow-sm" style={{ background: "var(--hayyah-blue)" }}>Contact Provider</Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
