import React, { useState } from "react";
import { AppLayout } from "./_shared/AppLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Search, 
  Plus, 
  MoreVertical, 
  Filter, 
  ChevronLeft, 
  ChevronRight,
  Phone,
  Mail,
  MapPin,
  Star,
  Clock,
  CheckCircle2,
  X
} from "lucide-react";

export function Customers() {
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);

  const customers = [
    { id: "1", name: "Ahmed Al-Farsi", phone: "+966 50 123 4567", email: "ahmed.f@example.com", city: "Riyadh", orders: 12, spent: "SAR 4,500", status: "VIP", joined: "Jan 12, 2023", initials: "AA" },
    { id: "2", name: "Sarah Rahman", phone: "+966 55 987 6543", email: "s.rahman@example.com", city: "Jeddah", orders: 4, spent: "SAR 1,200", status: "Active", joined: "Mar 05, 2023", initials: "SR" },
    { id: "3", name: "Mohammed Nasser", phone: "+966 53 456 7890", email: "m.nasser@example.com", city: "Dammam", orders: 8, spent: "SAR 2,800", status: "Active", joined: "Feb 20, 2023", initials: "MN" },
    { id: "4", name: "Fatima Saeed", phone: "+966 50 234 5678", email: "fatima.s@example.com", city: "Riyadh", orders: 1, spent: "SAR 300", status: "Inactive", joined: "Nov 15, 2023", initials: "FS" },
    { id: "5", name: "Khalid Basheer", phone: "+966 54 876 5432", email: "k.basheer@example.com", city: "Riyadh", orders: 15, spent: "SAR 6,200", status: "VIP", joined: "Dec 01, 2022", initials: "KB" },
    { id: "6", name: "Aisha Al-Dosari", phone: "+966 56 345 6789", email: "aisha.d@example.com", city: "Jeddah", orders: 3, spent: "SAR 950", status: "Active", joined: "Jun 10, 2023", initials: "AA" },
    { id: "7", name: "Omar Tariq", phone: "+966 50 765 4321", email: "o.tariq@example.com", city: "Dammam", orders: 6, spent: "SAR 1,800", status: "Active", joined: "Apr 22, 2023", initials: "OT" },
    { id: "8", name: "Leena Mansour", phone: "+966 55 123 9876", email: "leena.m@example.com", city: "Riyadh", orders: 0, spent: "SAR 0", status: "Inactive", joined: "Dec 05, 2023", initials: "LM" },
  ];

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "VIP": 
        return <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700 flex items-center gap-1 w-fit"><Star className="w-3 h-3 fill-current" /> VIP</span>;
      case "Active": 
        return <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-[#53ffb0]/20 text-emerald-700 w-fit">Active</span>;
      case "Inactive": 
        return <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 w-fit">Inactive</span>;
      default: 
        return null;
    }
  };

  const selectedData = customers.find(c => c.id === selectedCustomer);

  return (
    <AppLayout activeNav="customers">
      <div className="flex h-full gap-6">
        {/* Main Content */}
        <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${selectedCustomer ? 'lg:pr-[360px]' : ''}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold" style={{ color: "var(--hayyah-navy)" }}>Customers</h1>
              <p className="text-gray-500 text-sm mt-1">Manage and track all registered customers</p>
            </div>
            <Button className="gap-2 text-white shadow-sm" style={{ background: "var(--hayyah-blue)" }}>
              <Plus className="w-4 h-4" /> Add Customer
            </Button>
          </div>

          <Card className="rounded-2xl border-none shadow-sm bg-white flex flex-col flex-1 min-h-0 overflow-hidden">
            {/* Filter Bar */}
            <div className="p-4 border-b border-gray-100 flex flex-col sm:flex-row gap-4 justify-between items-center bg-white">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <Input placeholder="Search customers..." className="pl-9 bg-gray-50 border-transparent focus-visible:ring-[var(--hayyah-blue)]" />
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <Button variant="outline" className="gap-2 border-gray-200 text-gray-600">
                  <Filter className="w-4 h-4" /> Filters
                </Button>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[130px] border-gray-200">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="vip">VIP</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[130px] border-gray-200">
                    <SelectValue placeholder="City" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cities</SelectItem>
                    <SelectItem value="riyadh">Riyadh</SelectItem>
                    <SelectItem value="jeddah">Jeddah</SelectItem>
                    <SelectItem value="dammam">Dammam</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Table */}
            <div className="flex-1 overflow-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10 shadow-[0_1px_0_0_#f3f4f6]">
                  <TableRow className="hover:bg-transparent border-none">
                    <TableHead className="font-semibold text-gray-500 py-4 px-6">Customer</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4">Contact Info</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4">City</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4">Orders</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4">Total Spent</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4">Status</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4">Joined</TableHead>
                    <TableHead className="font-semibold text-gray-500 py-4 text-right px-6">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.map((customer, i) => (
                    <TableRow 
                      key={customer.id} 
                      className={`border-b border-gray-50 transition-colors cursor-pointer ${selectedCustomer === customer.id ? 'bg-[var(--hayyah-blue-light)]/50' : 'hover:bg-gray-50/50'}`}
                      onClick={() => setSelectedCustomer(customer.id)}
                    >
                      <TableCell className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9 border border-gray-100">
                            <AvatarFallback className="bg-[var(--hayyah-navy)] text-white text-xs font-medium">{customer.initials}</AvatarFallback>
                          </Avatar>
                          <span className="font-semibold" style={{ color: "var(--hayyah-navy)" }}>{customer.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-4">
                        <div className="flex flex-col gap-1">
                          <span className="text-sm text-gray-700">{customer.phone}</span>
                          <span className="text-xs text-gray-400">{customer.email}</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-4 text-gray-600">{customer.city}</TableCell>
                      <TableCell className="py-4 font-medium text-gray-900">{customer.orders}</TableCell>
                      <TableCell className="py-4 font-medium text-gray-900">{customer.spent}</TableCell>
                      <TableCell className="py-4">{getStatusBadge(customer.status)}</TableCell>
                      <TableCell className="py-4 text-gray-500 text-sm">{customer.joined}</TableCell>
                      <TableCell className="py-4 text-right px-6">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-900" onClick={(e) => e.stopPropagation()}>
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="p-4 border-t border-gray-100 flex items-center justify-between bg-white mt-auto">
              <span className="text-sm text-gray-500">Showing 1–8 of 842 customers</span>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="h-8 w-8 border-gray-200" disabled>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <div className="flex items-center gap-1">
                  <Button variant="outline" className="h-8 w-8 p-0 border-[var(--hayyah-blue)] text-[var(--hayyah-blue)] bg-[var(--hayyah-blue-light)]">1</Button>
                  <Button variant="ghost" className="h-8 w-8 p-0 text-gray-600">2</Button>
                  <Button variant="ghost" className="h-8 w-8 p-0 text-gray-600">3</Button>
                  <span className="text-gray-400 mx-1">...</span>
                  <Button variant="ghost" className="h-8 w-8 p-0 text-gray-600">106</Button>
                </div>
                <Button variant="outline" size="icon" className="h-8 w-8 border-gray-200">
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Side Panel (Overlay/Absolute on small screens, Side-by-side on lg) */}
        {selectedCustomer && selectedData && (
          <div className="fixed inset-y-0 right-0 w-[360px] bg-white shadow-2xl border-l border-gray-100 z-50 transform transition-transform duration-300 flex flex-col lg:absolute lg:right-6 lg:top-[90px] lg:bottom-6 lg:rounded-2xl lg:h-auto lg:border lg:shadow-md">
            {/* Header */}
            <div className="p-6 flex items-start justify-between border-b border-gray-100">
              <div className="flex items-center gap-4">
                <Avatar className="h-14 w-14 border-2 border-white shadow-sm ring-2 ring-[var(--hayyah-blue-light)]">
                  <AvatarFallback className="bg-[var(--hayyah-navy)] text-white text-lg font-bold">{selectedData.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-lg font-bold" style={{ color: "var(--hayyah-navy)" }}>{selectedData.name}</h2>
                  <div className="mt-1">{getStatusBadge(selectedData.status)}</div>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400" onClick={() => setSelectedCustomer(null)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              {/* Contact Info */}
              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-500">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-xs">Phone</p>
                      <p className="font-medium text-gray-900">{selectedData.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-500">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-xs">Email</p>
                      <p className="font-medium text-gray-900">{selectedData.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-500">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-gray-500 text-xs">Primary City</p>
                      <p className="font-medium text-gray-900">{selectedData.city}, Saudi Arabia</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats Mini */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl border border-gray-100 bg-gray-50/50">
                  <p className="text-xs text-gray-500 mb-1">Total Orders</p>
                  <p className="text-xl font-bold" style={{ color: "var(--hayyah-blue)" }}>{selectedData.orders}</p>
                </div>
                <div className="p-4 rounded-xl border border-gray-100 bg-gray-50/50">
                  <p className="text-xs text-gray-500 mb-1">Total Spent</p>
                  <p className="text-lg font-bold" style={{ color: "var(--hayyah-navy)" }}>{selectedData.spent}</p>
                </div>
              </div>

              {/* Recent History */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Recent Orders</h3>
                  <Button variant="link" className="text-xs h-auto p-0" style={{ color: "var(--hayyah-blue)" }}>View All</Button>
                </div>
                <div className="space-y-4">
                  {[1, 2, 3].map((_, idx) => (
                    <div key={idx} className="flex gap-3 relative pb-4 border-b border-gray-50 last:border-0 last:pb-0">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-[#53ffb0]/20 text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-900 truncate">Deep Cleaning Service</p>
                        <p className="text-xs text-gray-500 mt-0.5">Order #HY-2024-00{idx + 1} • SAR 450</p>
                        <p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><Clock className="w-3 h-3" /> Oct {12 - idx}, 2023</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-gray-100 bg-gray-50 flex gap-3">
              <Button variant="outline" className="flex-1 bg-white border-gray-200">Message</Button>
              <Button className="flex-1 text-white shadow-sm" style={{ background: "var(--hayyah-blue)" }}>Create Order</Button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
