import React, { useState } from "react";
import { AppLayout } from "./_shared/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Plus, 
  MapPin, 
  Star, 
  Briefcase, 
  CheckCircle2, 
  LayoutGrid, 
  List as ListIcon,
  Search,
  Filter,
  X,
  FileCheck,
  CalendarDays,
  ShieldCheck,
  ChevronRight
} from "lucide-react";

export function Providers() {
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);

  const stats = [
    { label: "Total Providers", value: "156" },
    { label: "Active Today", value: "34" },
    { label: "Avg. Rating", value: "4.7", isRating: true },
  ];

  const providers = [
    { id: "p1", name: "Omar Kahlil", initials: "OK", specialty: "Deep Cleaning Specialist", rating: 4.9, jobs: 142, activeJobs: 2, city: "Riyadh", status: "Available", skills: ["Deep Cleaning", "Carpet Cleaning", "Sanitization"] },
    { id: "p2", name: "Ali Mahmoud", initials: "AM", specialty: "AC Maintenance", rating: 4.8, jobs: 98, activeJobs: 1, city: "Jeddah", status: "Busy", skills: ["Split AC", "Central AC", "Duct Cleaning"] },
    { id: "p3", name: "Khaled Saqr", initials: "KS", specialty: "Pest Control", rating: 4.7, jobs: 85, activeJobs: 0, city: "Riyadh", status: "Off", skills: ["Insects", "Rodents", "Termites"] },
    { id: "p4", name: "Ibrahim W.", initials: "IW", specialty: "Plumbing", rating: 4.5, jobs: 64, activeJobs: 3, city: "Dammam", status: "Busy", skills: ["Leaks", "Pipe Fitting", "Water Heaters"] },
    { id: "p5", name: "Hassan Tarek", initials: "HT", specialty: "Deep Cleaning", rating: 4.6, jobs: 112, activeJobs: 0, city: "Riyadh", status: "Available", skills: ["Deep Cleaning", "Post-construction"] },
    { id: "p6", name: "Youssef Ali", initials: "YA", specialty: "Painting", rating: 4.9, jobs: 45, activeJobs: 1, city: "Jeddah", status: "Available", skills: ["Interior", "Exterior", "Wallpaper"] },
  ];

  const getStatusColor = (status: string) => {
    switch(status) {
      case "Available": return "bg-[#53ffb0] text-[#0d2270]";
      case "Busy": return "bg-amber-400 text-amber-900";
      case "Off": return "bg-gray-300 text-gray-700";
      default: return "bg-gray-200 text-gray-700";
    }
  };

  const selectedData = providers.find(p => p.id === selectedProvider);

  return (
    <AppLayout activeNav="providers">
      <div className="flex h-full gap-6">
        
        {/* Left Sidebar - Filters */}
        <div className="w-64 flex-shrink-0 hidden lg:flex flex-col bg-white rounded-2xl border-none shadow-sm p-5 h-[calc(100vh-120px)] sticky top-0 overflow-y-auto">
          <div className="flex items-center gap-2 mb-6">
            <Filter className="w-5 h-5 text-gray-400" />
            <h2 className="font-bold" style={{ color: "var(--hayyah-navy)" }}>Filters</h2>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold mb-3 text-gray-700">Specialty</h3>
              <div className="space-y-2.5">
                {["Deep Cleaning", "AC Maintenance", "Pest Control", "Plumbing", "Painting"].map(spec => (
                  <div key={spec} className="flex items-center space-x-2">
                    <Checkbox id={`spec-${spec}`} className="border-gray-300 data-[state=checked]:bg-[var(--hayyah-blue)] data-[state=checked]:border-[var(--hayyah-blue)]" />
                    <label htmlFor={`spec-${spec}`} className="text-sm text-gray-600 font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      {spec}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full h-px bg-gray-100" />

            <div>
              <h3 className="text-sm font-semibold mb-3 text-gray-700">City</h3>
              <div className="space-y-2.5">
                {["Riyadh", "Jeddah", "Dammam", "Mecca"].map(city => (
                  <div key={city} className="flex items-center space-x-2">
                    <Checkbox id={`city-${city}`} className="border-gray-300 data-[state=checked]:bg-[var(--hayyah-blue)] data-[state=checked]:border-[var(--hayyah-blue)]" />
                    <label htmlFor={`city-${city}`} className="text-sm text-gray-600 font-medium leading-none">
                      {city}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full h-px bg-gray-100" />

            <div>
              <h3 className="text-sm font-semibold mb-3 text-gray-700">Availability</h3>
              <div className="space-y-2.5">
                {["Available Now", "Busy", "Off Duty"].map(status => (
                  <div key={status} className="flex items-center space-x-2">
                    <Checkbox id={`status-${status}`} className="border-gray-300 data-[state=checked]:bg-[var(--hayyah-blue)] data-[state=checked]:border-[var(--hayyah-blue)]" />
                    <label htmlFor={`status-${status}`} className="text-sm text-gray-600 font-medium leading-none">
                      {status}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full h-px bg-gray-100" />

            <div>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-semibold text-gray-700">Minimum Rating</h3>
                <span className="text-xs font-bold text-[var(--hayyah-blue)]">4.0+</span>
              </div>
              <Slider defaultValue={[4]} max={5} step={0.5} className="mt-4" />
              <div className="flex justify-between text-xs text-gray-400 mt-2">
                <span>0</span>
                <span>5</span>
              </div>
            </div>
          </div>
          
          <div className="mt-auto pt-6">
            <Button className="w-full bg-gray-100 text-gray-700 hover:bg-gray-200">Reset Filters</Button>
          </div>
        </div>

        {/* Main Content */}
        <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${selectedProvider ? 'xl:pr-[380px]' : ''}`}>
          
          {/* Header & Stats */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl font-bold" style={{ color: "var(--hayyah-navy)" }}>Service Providers</h1>
              <p className="text-gray-500 text-sm mt-1">Manage and track your service fleet</p>
            </div>
            <Button className="gap-2 text-white shadow-sm" style={{ background: "var(--hayyah-blue)" }}>
              <Plus className="w-4 h-4" /> Add Provider
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            {stats.map((stat, i) => (
              <Card key={i} className="rounded-xl border-none shadow-sm bg-white">
                <CardContent className="p-5 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">{stat.label}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <p className="text-2xl font-bold" style={{ color: "var(--hayyah-navy)" }}>{stat.value}</p>
                      {stat.isRating && <Star className="w-5 h-5 fill-amber-400 text-amber-400 mb-1" />}
                    </div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-[var(--hayyah-blue-light)] flex items-center justify-center">
                    <Briefcase className="w-5 h-5" style={{ color: "var(--hayyah-blue)" }} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* View Toggle & Search */}
          <div className="flex items-center justify-between mb-6">
            <div className="relative w-full max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search providers by name or ID..." 
                className="w-full pl-9 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[var(--hayyah-blue)]/20 focus:border-[var(--hayyah-blue)] transition-all shadow-sm"
              />
            </div>
            
            <div className="flex bg-white rounded-lg p-1 border border-gray-200 shadow-sm">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-gray-100 text-[var(--hayyah-navy)]' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-md transition-colors ${viewMode === 'table' ? 'bg-gray-100 text-[var(--hayyah-navy)]' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <ListIcon className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Grid View */}
          {viewMode === 'grid' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-5 pb-6">
              {providers.map((provider) => (
                <Card 
                  key={provider.id} 
                  className={`rounded-2xl border-none shadow-sm overflow-hidden cursor-pointer transition-all hover:shadow-md hover:-translate-y-1 ${selectedProvider === provider.id ? 'ring-2 ring-[var(--hayyah-blue)]' : ''}`}
                  onClick={() => setSelectedProvider(provider.id)}
                >
                  <CardContent className="p-0">
                    <div className="p-5 flex gap-4">
                      <div className="relative">
                        <Avatar className="h-16 w-16 border-2 border-white shadow-sm">
                          <AvatarFallback className="text-lg font-bold text-white" style={{ background: "var(--hayyah-navy)" }}>{provider.initials}</AvatarFallback>
                        </Avatar>
                        <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${getStatusColor(provider.status).split(' ')[0]}`} title={provider.status} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-base truncate" style={{ color: "var(--hayyah-navy)" }}>{provider.name}</h3>
                        <p className="text-xs text-[var(--hayyah-blue)] font-medium mt-0.5 truncate">{provider.specialty}</p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                          <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {provider.city}</span>
                          <span className="flex items-center gap-1"><Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {provider.rating}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="px-5 py-3 bg-gray-50 flex justify-between border-t border-gray-100">
                      <div className="text-center">
                        <p className="text-xs text-gray-500 mb-0.5">Completed</p>
                        <p className="font-semibold text-gray-900">{provider.jobs}</p>
                      </div>
                      <div className="w-px h-8 bg-gray-200" />
                      <div className="text-center">
                        <p className="text-xs text-gray-500 mb-0.5">Active Now</p>
                        <p className="font-semibold" style={{ color: provider.activeJobs > 0 ? "var(--hayyah-blue)" : "inherit" }}>{provider.activeJobs}</p>
                      </div>
                      <div className="w-px h-8 bg-gray-200" />
                      <div className="flex items-center justify-center pt-1">
                        <Button size="sm" variant="ghost" className="h-7 text-xs font-semibold px-2" style={{ color: "var(--hayyah-blue)" }}>
                          View <ChevronRight className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

        </div>

        {/* Detail Panel */}
        {selectedProvider && selectedData && (
          <div className="fixed inset-y-0 right-0 w-[380px] bg-white shadow-2xl border-l border-gray-100 z-50 transform transition-transform duration-300 flex flex-col xl:absolute xl:right-6 xl:top-[90px] xl:bottom-6 xl:rounded-2xl xl:h-auto xl:border xl:shadow-md">
            
            <div className="h-32 bg-[var(--hayyah-blue-light)] relative flex-shrink-0 xl:rounded-t-2xl">
              <Button variant="ghost" size="icon" className="absolute top-4 right-4 h-8 w-8 bg-white/50 hover:bg-white text-[var(--hayyah-navy)] rounded-full backdrop-blur-sm" onClick={() => setSelectedProvider(null)}>
                <X className="w-5 h-5" />
              </Button>
              <div className="absolute -bottom-10 left-6">
                <Avatar className="h-20 w-20 border-4 border-white shadow-md">
                  <AvatarFallback className="text-2xl font-bold text-white" style={{ background: "var(--hayyah-navy)" }}>{selectedData.initials}</AvatarFallback>
                </Avatar>
                <div className={`absolute bottom-1 right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(selectedData.status).split(' ')[0]}`} />
              </div>
            </div>

            <div className="pt-14 px-6 pb-4 border-b border-gray-100 flex-shrink-0">
              <h2 className="text-xl font-bold" style={{ color: "var(--hayyah-navy)" }}>{selectedData.name}</h2>
              <p className="text-sm font-medium text-[var(--hayyah-blue)] mt-1">{selectedData.specialty}</p>
              
              <div className="flex flex-wrap gap-2 mt-4">
                {selectedData.skills.map((skill, idx) => (
                  <span key={idx} className="px-2.5 py-1 bg-[var(--hayyah-blue-light)] text-[var(--hayyah-blue)] text-xs font-semibold rounded-md">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              
              {/* Verification */}
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Verification Status</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-5 h-5 text-emerald-500" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-900">Background Check</p>
                      <p className="text-xs text-gray-500">Verified on Jan 15, 2023</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <FileCheck className="w-5 h-5 text-emerald-500" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-900">ID & Certifications</p>
                      <p className="text-xs text-gray-500">All documents up to date</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Performance */}
              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Performance</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="border border-gray-100 rounded-xl p-4 text-center">
                    <div className="flex justify-center mb-1">
                      <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                    </div>
                    <p className="text-xl font-bold" style={{ color: "var(--hayyah-navy)" }}>{selectedData.rating}</p>
                    <p className="text-xs text-gray-500">Average Rating</p>
                  </div>
                  <div className="border border-gray-100 rounded-xl p-4 text-center">
                    <div className="flex justify-center mb-1">
                      <CheckCircle2 className="w-5 h-5 text-[#53ffb0]" />
                    </div>
                    <p className="text-xl font-bold" style={{ color: "var(--hayyah-navy)" }}>98%</p>
                    <p className="text-xs text-gray-500">Completion Rate</p>
                  </div>
                </div>
              </div>

              {/* Today's Schedule */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Today's Schedule</h3>
                  <Button variant="link" className="text-xs h-auto p-0 flex items-center gap-1" style={{ color: "var(--hayyah-blue)" }}>
                    <CalendarDays className="w-3 h-3" /> Full Calendar
                  </Button>
                </div>
                
                {selectedData.activeJobs > 0 ? (
                  <div className="space-y-3">
                    {[...Array(selectedData.activeJobs)].map((_, idx) => (
                      <div key={idx} className="flex gap-3 relative pl-4 border-l-2 border-[var(--hayyah-blue)] py-1">
                        <div className="flex-1">
                          <p className="text-xs font-bold text-[var(--hayyah-blue)]">{10 + (idx*3)}:00 AM - {12 + (idx*3)}:00 PM</p>
                          <p className="text-sm font-semibold text-gray-900 mt-0.5">{selectedData.specialty} Service</p>
                          <p className="text-xs text-gray-500 mt-1 flex items-center gap-1"><MapPin className="w-3 h-3" /> {selectedData.city} District</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-gray-50 rounded-xl p-6 text-center border border-gray-100 border-dashed">
                    <p className="text-sm text-gray-500">No active jobs scheduled for today.</p>
                  </div>
                )}
              </div>

            </div>

            <div className="p-4 border-t border-gray-100 bg-white flex gap-3 xl:rounded-b-2xl shadow-[0_-4px_10px_rgba(0,0,0,0.02)]">
              <Button variant="outline" className="flex-1 bg-white border-gray-200">Message</Button>
              <Button className="flex-1 text-white shadow-sm" style={{ background: "var(--hayyah-blue)" }}>Assign Job</Button>
            </div>
          </div>
        )}

      </div>
    </AppLayout>
  );
}
