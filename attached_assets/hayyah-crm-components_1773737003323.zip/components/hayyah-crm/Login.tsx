import { useState } from "react";
import { Eye, EyeOff, Home, ArrowRight, Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";

export function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("admin@hayyah.sa");
  const [password, setPassword] = useState("••••••••••");

  return (
    <div
      className="flex h-screen w-full overflow-hidden"
      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
    >
      {/* ─── Left panel – brand illustration ─── */}
      <div
        className="relative hidden lg:flex flex-col justify-between w-[55%] p-12 overflow-hidden"
        style={{ background: "var(--hayyah-navy, #0d2270)" }}
      >
        {/* Background geometric blobs */}
        <div
          className="absolute -top-32 -left-32 w-[500px] h-[500px] rounded-full opacity-20"
          style={{ background: "var(--hayyah-blue, #0088fb)" }}
        />
        <div
          className="absolute bottom-0 right-0 w-[400px] h-[400px] rounded-full opacity-10"
          style={{ background: "var(--hayyah-mint, #53ffb0)" }}
        />
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full opacity-5"
          style={{ background: "var(--hayyah-blue, #0088fb)" }}
        />

        {/* Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <img
            src="/__mockup/images/hayyah-wordmark-white.png"
            alt="hayyah"
            style={{ height: 40, width: "auto" }}
          />
          <div className="text-sm font-medium ml-1" style={{ color: "rgba(255,255,255,0.4)", letterSpacing: "0.12em" }}>
            CRM
          </div>
        </div>

        {/* Center illustration */}
        <div className="relative z-10 flex flex-col items-center text-center gap-8 px-8">
          {/* Abstract house icon area */}
          <div className="relative">
            <div
              className="flex items-center justify-center rounded-3xl"
              style={{ width: 180, height: 180, background: "rgba(0,136,251,0.15)", border: "1px solid rgba(0,136,251,0.3)" }}
            >
              <Home className="w-20 h-20" style={{ color: "var(--hayyah-blue, #0088fb)" }} />
            </div>
            {/* Floating badges */}
            <div
              className="absolute -top-4 -right-8 flex items-center gap-2 px-4 py-2 rounded-2xl"
              style={{ background: "rgba(83,255,176,0.15)", border: "1px solid rgba(83,255,176,0.3)" }}
            >
              <Sparkles className="w-4 h-4" style={{ color: "var(--hayyah-mint, #53ffb0)" }} />
              <span className="text-sm font-semibold" style={{ color: "var(--hayyah-mint, #53ffb0)" }}>
                1,284 Orders
              </span>
            </div>
            <div
              className="absolute -bottom-4 -left-10 flex items-center gap-2 px-4 py-2 rounded-2xl"
              style={{ background: "rgba(0,136,251,0.15)", border: "1px solid rgba(0,136,251,0.3)" }}
            >
              <Shield className="w-4 h-4" style={{ color: "var(--hayyah-blue, #0088fb)" }} />
              <span className="text-sm font-semibold text-white">
                156 Providers
              </span>
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-bold text-white mb-3 leading-snug">
              Manage Your Home<br />Services Smarter
            </h2>
            <p style={{ color: "rgba(255,255,255,0.55)", fontSize: 15, lineHeight: 1.7 }}>
              The all-in-one CRM for home care and cleaning services.<br />
              Track orders, manage providers, and delight customers.
            </p>
          </div>

          {/* Stats row */}
          <div className="flex gap-8">
            {[
              { value: "842", label: "Customers" },
              { value: "4.8★", label: "Avg. Rating" },
              { value: "SAR 128K", label: "Monthly Rev." },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.45)" }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom tagline */}
        <div className="relative z-10 flex items-center gap-2" style={{ color: "rgba(255,255,255,0.3)", fontSize: 13 }}>
          <div className="w-6 h-px" style={{ background: "rgba(255,255,255,0.2)" }} />
          Hayyah — Home Care & Cleaning Services
        </div>
      </div>

      {/* ─── Right panel – login form ─── */}
      <div
        className="flex flex-col justify-center flex-1 px-10 py-12"
        style={{ background: "#f0f4f8" }}
      >
        <div className="w-full max-w-sm mx-auto">
          {/* Mobile logo (hidden on large screens) */}
          <div className="flex items-center gap-2 mb-10 lg:hidden">
            <img
              src="/__mockup/images/hayyah-wordmark-blue.png"
              alt="hayyah"
              style={{ height: 28, width: "auto" }}
            />
          </div>

          {/* Heading */}
          <div className="mb-8">
            <h1 className="text-2xl font-bold mb-1" style={{ color: "var(--hayyah-navy, #0d2270)" }}>
              Welcome back
            </h1>
            <p style={{ color: "#64748b", fontSize: 14 }}>
              Sign in to your CRM dashboard
            </p>
          </div>

          {/* Form */}
          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            {/* Email */}
            <div className="space-y-1.5">
              <label className="text-sm font-semibold" style={{ color: "#374151" }}>
                Email Address
              </label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 rounded-xl border-0 text-sm"
                style={{ background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.08)" }}
                placeholder="you@hayyah.sa"
              />
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-sm font-semibold" style={{ color: "#374151" }}>
                  Password
                </label>
                <button
                  type="button"
                  className="text-xs font-medium"
                  style={{ color: "var(--hayyah-blue, #0088fb)" }}
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 rounded-xl border-0 pr-10 text-sm"
                  style={{ background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.08)" }}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: "#94a3b8" }}
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember me */}
            <div className="flex items-center gap-2">
              <Checkbox id="remember" defaultChecked />
              <label htmlFor="remember" className="text-sm" style={{ color: "#64748b" }}>
                Remember me for 30 days
              </label>
            </div>

            {/* Sign in button */}
            <Button
              type="submit"
              className="w-full h-11 rounded-xl text-sm font-semibold flex items-center justify-center gap-2"
              style={{ background: "var(--hayyah-blue, #0088fb)", color: "#fff", border: "none" }}
            >
              Sign In
              <ArrowRight className="w-4 h-4" />
            </Button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px" style={{ background: "#e2e8f0" }} />
            <span className="text-xs" style={{ color: "#94a3b8" }}>or continue with</span>
            <div className="flex-1 h-px" style={{ background: "#e2e8f0" }} />
          </div>

          {/* Google SSO */}
          <button
            className="w-full flex items-center justify-center gap-3 h-11 rounded-xl text-sm font-medium transition-all"
            style={{ background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.08)", color: "#374151" }}
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Continue with Google
          </button>

          {/* Security note */}
          <div
            className="flex items-center gap-2 mt-8 p-3 rounded-xl"
            style={{ background: "rgba(0,136,251,0.06)", border: "1px solid rgba(0,136,251,0.12)" }}
          >
            <Shield className="w-4 h-4 flex-shrink-0" style={{ color: "var(--hayyah-blue, #0088fb)" }} />
            <p className="text-xs" style={{ color: "#64748b" }}>
              Secured with enterprise-grade encryption. Your data is safe.
            </p>
          </div>

          {/* Footer */}
          <p className="text-center text-xs mt-6" style={{ color: "#94a3b8" }}>
            © 2026 Hayyah. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}
