import React, { useState } from "react";
import { AppLayout } from "./_shared/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Users, 
  ShoppingBag, 
  DollarSign, 
  Star, 
  Plus, 
  UserPlus, 
  Wrench, 
  ArrowUpRight, 
  ArrowDownRight,
  MoreVertical
} from "lucide-react";

export function Dashboard() {
  const stats = [
    { label: "Total Orders", value: "1,284", icon: ShoppingBag, trend: "+12%", positive: true },
    { label: "Active Customers", value: "842", icon: Users, trend: "+8%", positive: true },
    { label: "Revenue This Month", value: "SAR 128,500", icon: DollarSign, trend: "+24%", positive: true },
    { label: "Avg. Service Rating", value: "4.8", icon: Star, trend: "-2%", positive: false },
  ];

  const recentOrders = [
    { id: "#HY-2024-001", customer: "Ahmed Al-Farsi", service: "Deep Cleaning", provider: "Omar K.", status: "Completed", amount: "SAR 450", date: "Today, 10:30 AM" },
    { id: "#HY-2024-002", customer: "Sarah R.", service: "Pest Control", provider: "Unassigned", status: "Pending", amount: "SAR 250", date: "Today, 12:00 PM" },
    { id: "#HY-2024-003", customer: "Mohammed N.", service: "AC Maintenance", provider: "Ali M.", status: "In Progress", amount: "SAR 300", date: "Today, 09:15 AM" },
    { id: "#HY-2024-004", customer: "Fatima S.", service: "Deep Cleaning", provider: "Hassan T.", status: "Cancelled", amount: "SAR 450", date: "Yesterday" },
    { id: "#HY-2024-005", customer: "Khalid B.", service: "Plumbing", provider: "Ibrahim W.", status: "Completed", amount: "SAR 150", date: "Yesterday" },
  ];

  const getStatusColor = (status: string) => {
    switch(status) {
      case "Completed": return "bg-[#53ffb0]/20 text-[#0d2270]";
      case "In Progress": return "bg-[#0088fb]/20 text-[#0088fb]";
      case "Pending": return "bg-amber-100 text-amber-800";
      case "Cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const topProviders = [
    { name: "Omar K.", service: "Deep Cleaning", jobs: 142, rating: 4.9 },
    { name: "Ali M.", service: "AC Maintenance", jobs: 98, rating: 4.8 },
    { name: "Khaled S.", service: "Pest Control", jobs: 85, rating: 4.7 },
  ];

  return (
    <AppLayout activeNav="dashboard">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Header & Quick Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold" style={{ color: "var(--hayyah-navy)" }}>Dashboard Overview</h1>
            <p className="text-gray-500 text-sm mt-1">Welcome back! Here's what's happening today.</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="gap-2 bg-white text-[var(--hayyah-navy)] border-gray-200">
              <UserPlus className="w-4 h-4" /> Add Customer
            </Button>
            <Button variant="outline" className="gap-2 bg-white text-[var(--hayyah-navy)] border-gray-200">
              <Wrench className="w-4 h-4" /> Assign Provider
            </Button>
            <Button className="gap-2 text-white" style={{ background: "var(--hayyah-blue)" }}>
              <Plus className="w-4 h-4" /> New Order
            </Button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <Card key={i} className="rounded-2xl border-none shadow-sm overflow-hidden bg-white">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div 
                      className="p-3 rounded-xl" 
                      style={{ background: "var(--hayyah-blue-light)" }}
                    >
                      <Icon className="w-5 h-5" style={{ color: "var(--hayyah-blue)" }} />
                    </div>
                    <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${stat.positive ? 'text-green-700 bg-green-50' : 'text-red-700 bg-red-50'}`}>
                      {stat.positive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                      {stat.trend}
                    </div>
                  </div>
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-gray-500">{stat.label}</h3>
                    <p className="text-2xl font-bold mt-1" style={{ color: "var(--hayyah-navy)" }}>{stat.value}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Revenue Chart Placeholder */}
          <Card className="lg:col-span-2 rounded-2xl border-none shadow-sm bg-white">
            <CardHeader className="border-b border-gray-50 pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-bold flex items-center gap-2" style={{ color: "var(--hayyah-navy)" }}>
                  <div className="w-1 h-5 rounded-full" style={{ background: "var(--hayyah-blue)" }} />
                  Revenue Overview
                </CardTitle>
                <select className="text-sm border-gray-200 rounded-lg text-gray-500 bg-gray-50 px-2 py-1 outline-none">
                  <option>2024</option>
                  <option>2023</option>
                </select>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="h-64 flex items-end justify-between gap-2 pb-6 relative">
                {/* Y-axis labels */}
                <div className="absolute left-0 top-0 bottom-6 flex flex-col justify-between text-xs text-gray-400 w-12 text-right pr-4">
                  <span>150k</span>
                  <span>100k</span>
                  <span>50k</span>
                  <span>0</span>
                </div>
                
                {/* Grid lines */}
                <div className="absolute left-12 right-0 top-2 border-t border-dashed border-gray-200 w-full" />
                <div className="absolute left-12 right-0 top-[33%] border-t border-dashed border-gray-200 w-full" />
                <div className="absolute left-12 right-0 top-[66%] border-t border-dashed border-gray-200 w-full" />
                <div className="absolute left-12 right-0 bottom-6 border-t border-dashed border-gray-200 w-full" />

                {/* Bars */}
                <div className="w-full flex justify-between items-end pl-14 relative z-10 h-full">
                  {[40, 60, 45, 80, 55, 90, 100, 75, 85, 120, 95, 110].map((height, i) => (
                    <div key={i} className="flex flex-col items-center gap-2 w-full">
                      <div className="w-full max-w-[28px] mx-auto rounded-t-md relative group" style={{ height: `${height}%`, background: i === 9 ? "var(--hayyah-blue)" : "var(--hayyah-blue-light)" }}>
                        {i === 9 && (
                          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[var(--hayyah-navy)] text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                            SAR 120k
                          </div>
                        )}
                      </div>
                      <span className="text-xs text-gray-500 font-medium">
                        {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Top Providers */}
          <Card className="rounded-2xl border-none shadow-sm bg-white">
            <CardHeader className="border-b border-gray-50 pb-4">
              <CardTitle className="text-base font-bold flex items-center gap-2" style={{ color: "var(--hayyah-navy)" }}>
                <div className="w-1 h-5 rounded-full" style={{ background: "var(--hayyah-mint)" }} />
                Top Providers
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-gray-50">
                {topProviders.map((provider, i) => (
                  <div key={i} className="p-5 flex items-center justify-between hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-white" style={{ background: "var(--hayyah-navy)" }}>
                        {provider.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <h4 className="font-semibold text-sm" style={{ color: "var(--hayyah-navy)" }}>{provider.name}</h4>
                        <p className="text-xs text-gray-500">{provider.service}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center justify-end gap-1 text-xs font-semibold" style={{ color: "var(--hayyah-blue)" }}>
                        <Star className="w-3 h-3 fill-current" /> {provider.rating}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{provider.jobs} jobs</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-4 border-t border-gray-50">
                <Button variant="ghost" className="w-full text-sm font-medium" style={{ color: "var(--hayyah-blue)" }}>
                  View All Providers
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Orders Table */}
        <Card className="rounded-2xl border-none shadow-sm bg-white overflow-hidden">
          <CardHeader className="border-b border-gray-50 pb-4 flex flex-row items-center justify-between">
            <CardTitle className="text-base font-bold flex items-center gap-2" style={{ color: "var(--hayyah-navy)" }}>
              <div className="w-1 h-5 rounded-full" style={{ background: "var(--hayyah-blue)" }} />
              Recent Orders
            </CardTitle>
            <Button variant="link" className="text-sm font-medium h-auto p-0" style={{ color: "var(--hayyah-blue)" }}>
              View All
            </Button>
          </CardHeader>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/50 hover:bg-gray-50/50 border-gray-100">
                  <TableHead className="font-semibold text-gray-500">Order ID</TableHead>
                  <TableHead className="font-semibold text-gray-500">Customer</TableHead>
                  <TableHead className="font-semibold text-gray-500">Service</TableHead>
                  <TableHead className="font-semibold text-gray-500">Provider</TableHead>
                  <TableHead className="font-semibold text-gray-500">Status</TableHead>
                  <TableHead className="font-semibold text-gray-500">Amount</TableHead>
                  <TableHead className="font-semibold text-gray-500 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentOrders.map((order, i) => (
                  <TableRow key={i} className="border-gray-50 hover:bg-gray-50/50 transition-colors">
                    <TableCell className="font-medium" style={{ color: "var(--hayyah-navy)" }}>{order.id}</TableCell>
                    <TableCell>
                      <div className="font-medium text-sm text-gray-900">{order.customer}</div>
                      <div className="text-xs text-gray-400">{order.date}</div>
                    </TableCell>
                    <TableCell className="text-gray-600">{order.service}</TableCell>
                    <TableCell className="text-gray-600">{order.provider}</TableCell>
                    <TableCell>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {order.status}
                      </span>
                    </TableCell>
                    <TableCell className="font-medium text-gray-900">{order.amount}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-900">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </AppLayout>
  );
}
